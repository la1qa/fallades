"""Agrupa alertes que probablement són el MATEIX incident (mateix usuari, equip, IP atacant, etc.).

Idea: dues alertes s'uneixen si comparteixen una entitat "específica" i passen a prop en el temps.
Les entitats massa comunes (la IP de l'oficina, dominis de campanya massiva...) NO uneixen res.

Ús (des de l'arrel del projecte, al costat de 03_alertas):
    python agrupar_alertas.py                 # totes les alertes (alertas.jsonl)
    python agrupar_alertas.py --muestra       # només la mostra de 150
    python agrupar_alertas.py --ventana 48    # finestra de temps en hores (per defecte 24)
    python agrupar_alertas.py --hub 25        # entitats amb més alertes que això no uneixen
Sortida: grupos/grupos.json  (+ resum per pantalla)
"""
import argparse, collections, json
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SEV = {"informational": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
IGNORAR = {("ip", "198.18.200.10")}      # sortida a internet de l'oficina: surt a centenars d'alertes


def entidades(a):
    """Retorna les entitats d'una alerta com a parelles (tipus, valor)."""
    e, out = a.get("entities", {}), []
    out += [("user", u["upn"]) for u in e.get("users", []) if "@" in u.get("upn", "")]  # salta "(12 cuentas)"
    out += [("host", h["hostname"]) for h in e.get("hosts", [])]
    out += [("ip", i) for i in e.get("ips", [])]
    out += [("domain", d) for d in e.get("domains", [])]
    out += [("hash", f["sha256"]) for f in e.get("files", []) if f.get("sha256")]
    out += [("client", c["customer_id"]) for c in e.get("customers", []) if isinstance(c, dict)]
    if e.get("ai_session"):
        out.append(("sessio_ia", e["ai_session"]))
    if isinstance(e.get("cloud"), dict) and e["cloud"].get("identity"):
        out.append(("identitat_cloud", e["cloud"]["identity"]))
    return list(dict.fromkeys(out))


def agrupar(alertas, ventana_h=24, hub=25):
    alertas = sorted(alertas, key=lambda a: a["created_at"])
    t = {a["alert_id"]: datetime.fromisoformat(a["created_at"].replace("Z", "+00:00")) for a in alertas}
    grau = collections.Counter(k for a in alertas for k in entidades(a))
    pare = {a["alert_id"]: a["alert_id"] for a in alertas}

    def arrel(x):
        while pare[x] != x:
            pare[x] = pare[pare[x]]
            x = pare[x]
        return x

    ultima = {}
    for a in alertas:
        for k in entidades(a):
            if k in IGNORAR or grau[k] > hub:
                continue                                    # entitat massa comuna: no uneix
            if k in ultima and (t[a["alert_id"]] - t[ultima[k]]).total_seconds() <= ventana_h * 3600:
                pare[arrel(a["alert_id"])] = arrel(ultima[k])
            ultima[k] = a["alert_id"]

    grups = collections.defaultdict(list)
    for a in alertas:
        grups[arrel(a["alert_id"])].append(a)

    sortida = []
    for membres in grups.values():
        comptes = collections.Counter(k for a in membres for k in entidades(a)
                                      if k not in IGNORAR and grau[k] <= hub)
        compartides = [f"{tipus}:{val}" for (tipus, val), n in comptes.most_common() if n >= 2]
        regles = [a["rule_id"] for a in membres]
        sev_max = max((a["severity"] for a in membres), key=SEV.get)
        if len(membres) == 1:
            tipus = "individual"
        elif len(set(regles)) >= 3:
            tipus = "multietapa"            # diverses regles diferents: pot ser una cadena d'atac
        else:
            tipus = "repetit"               # la mateixa regla repetida
        sortida.append({
            "group_id": "", "tipus": tipus, "n_alertes": len(membres),
            "alert_ids": [a["alert_id"] for a in membres],
            "regles": regles, "runbooks": sorted({a["runbook"] for a in membres}),
            "severitat_regla_max": sev_max,
            "inici": membres[0]["created_at"], "fi": membres[-1]["created_at"],
            "entitats_compartides": compartides[:8],
            "usuaris": sorted({v for (k, v) in comptes if k == "user"}),
            "equips": sorted({v for (k, v) in comptes if k == "host"}),
        })
    # ordre: primer els multietapa i amb més regles diferents, després per severitat de regla
    sortida.sort(key=lambda g: (g["tipus"] != "multietapa", -len(set(g["regles"])),
                                -SEV[g["severitat_regla_max"]], g["inici"]))
    for i, g in enumerate(sortida, 1):
        g["group_id"] = f"GRP-{i:04d}"
    return sortida


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--muestra", action="store_true", help="usa alertas_muestra_desarrollo.jsonl")
    p.add_argument("--ventana", type=int, default=24, help="hores entre alertes que comparteixen entitat")
    p.add_argument("--hub", type=int, default=25, help="entitats amb més alertes que això no uneixen")
    a = p.parse_args()
    nom = "alertas_muestra_desarrollo.jsonl" if a.muestra else "alertas.jsonl"
    ruta = ROOT / "03_alertas" / nom
    alertas = [json.loads(l) for l in ruta.read_text(encoding="utf-8").splitlines() if l.strip()]
    grups = agrupar(alertas, a.ventana, a.hub)

    (ROOT / "grupos").mkdir(exist_ok=True)
    (ROOT / "grupos" / "grupos.json").write_text(json.dumps(grups, ensure_ascii=False, indent=1), encoding="utf-8")

    comptes = collections.Counter(g["tipus"] for g in grups)
    print(f"{len(alertas)} alertes → {len(grups)} grups  (finestra {a.ventana}h, hub>{a.hub})")
    print("Per tipus:", dict(comptes))
    print(f"Alertes dins de grups multietapa: {sum(g['n_alertes'] for g in grups if g['tipus'] == 'multietapa')}")
    print("\nTOP 10 grups (multietapa primer):")
    for g in grups[:10]:
        print(f" {g['group_id']} [{g['tipus']}] {g['n_alertes']} alertes, {len(set(g['regles']))} regles, "
              f"màx {g['severitat_regla_max']}, {g['inici'][:16]} → {g['fi'][:16]}")
        print(f"     compartit: {', '.join(g['entitats_compartides'][:3])}")
        print(f"     regles: {' → '.join(g['regles'][:8])}")
    print("\nGuardat a grupos/grupos.json")


if __name__ == "__main__":
    main()
