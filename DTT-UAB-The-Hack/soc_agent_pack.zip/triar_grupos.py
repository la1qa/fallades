"""Passa l'agent per GRUPS d'alertes (un sol tiquet per incident probable).

Requisits: haver executat  python agrupar_alertas.py  (crea grupos/grupos.json),
API del SOC encesa i DCC_API_KEY posada. Posa aquest fitxer al costat d'agente_soc_dcc*.py.
Si el teu fitxer de l'agent es diu agente_soc_dcc_v2.py, canvia la línia 'import' de sota.

    python triar_grupos.py                    # els 3 primers grups (multietapa primer)
    python triar_grupos.py --top 5
    python triar_grupos.py --grupos GRP-0001 GRP-0004
"""
import argparse, contextlib, io, json, os, sys, time
from datetime import datetime
from pathlib import Path

import importlib, os
ag = importlib.import_module(os.getenv("SOC_AGENT_MODULE", "agente_soc_dcc_v2_2"))  # canvia-ho amb la variable SOC_AGENT_MODULE

SEV = {"informational": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
INSTRUCCIO = (
    "Este caso AGRUPA varias alertas que comparten entidades en una ventana de tiempo. La agrupación es solo una "
    "HIPÓTESIS: comprueba si de verdad forman UNA cadena de ataque (orden temporal, mismo usuario/equipo/indicador, "
    "causalidad). Emite UN ÚNICO ticket para el caso, con alert_ids = todas las alertas del grupo. La severidad es la "
    "del incidente completo: si la cadena es real y llega a ejecución/acceso/exfiltración, sube; si las alertas solo "
    "coinciden por casualidad, dilo en el resumen y en open_questions y no las fuerces a ser un incidente.")


class SoloTraza(io.TextIOBase):
    def __init__(self, real):
        self.real, self.buf = real, ""
    def write(self, s):
        self.buf += s
        while "\n" in self.buf:
            linia, self.buf = self.buf.split("\n", 1)
            if linia.startswith(("[SOC API]", "[IA]")):
                self.real.write("     " + linia + "\n"); self.real.flush()
        return len(s)
    def flush(self):
        self.real.flush()


def alerta_de_grupo(g, per_id):
    membres = [per_id[i] for i in g["alert_ids"]]
    rep = sorted(membres, key=lambda a: (-SEV[a["severity"]], a["created_at"]))[0]   # la més greu
    camps = ("alert_id", "created_at", "rule_id", "rule_name", "severity", "runbook", "source_product",
             "entities", "evidence", "related_events")
    d = dict(rep)
    d["created_at"] = g["inici"]
    d["runbook"] = "RB-GRUPO"                      # fitxer temporal amb tots els runbooks del grup
    d["caso_agrupado"] = {
        "group_id": g["group_id"], "n_alertas": len(membres), "alert_ids": g["alert_ids"],
        "ventana_utc": {"inicio": g["inici"], "fin": g["fi"]},
        "entidades_compartidas": g["entitats_compartides"], "instruccion": INSTRUCCIO,
        "alertas": [{k: a.get(k) for k in camps} for a in membres]}
    return d


@contextlib.contextmanager
def runbook_temporal(g):
    """Crea 01_contexto/runbooks/RB-GRUPO.md amb tots els runbooks del grup i l'esborra al final."""
    carpeta = ag.ROOT / "01_contexto" / "runbooks"
    text = []
    for rb in g["runbooks"]:
        ruta = carpeta / f"{rb}.md"
        if ruta.exists():
            text.append(f"## RUNBOOK {rb}\n\n{ruta.read_text(encoding='utf-8')}")
    destino = carpeta / "RB-GRUPO.md"
    destino.write_text("\n\n---\n\n".join(text) or "Runbooks no disponibles", encoding="utf-8")
    try:
        yield
    finally:
        destino.unlink(missing_ok=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--top", type=int, default=3)
    p.add_argument("--grupos", nargs="*", help="p. ex. GRP-0001 GRP-0004")
    args = p.parse_args()

    ruta = ag.ROOT / "grupos" / "grupos.json"
    if not ruta.exists():
        sys.exit("✖ Falta grupos/grupos.json. Executa primer:  python agrupar_alertas.py")
    grups = json.loads(ruta.read_text(encoding="utf-8"))
    triats = [g for g in grups if g["group_id"] in args.grupos] if args.grupos else grups[:args.top]
    try:
        ag.get("/alerts", limit=1)
    except Exception:
        sys.exit(f"✖ L'API del SOC no respon a {ag.BASE}. Engega-la: cd 06_herramientas ; uvicorn mock_soc_api:app --port 8000")

    per_id = {}
    for l in (ag.ROOT / "03_alertas" / "alertas.jsonl").read_text(encoding="utf-8").splitlines():
        if l.strip():
            a = json.loads(l); per_id[a["alert_id"]] = a
    carpeta = ag.ROOT / "resultados_grupos" / datetime.now().strftime("%Y%m%d_%H%M%S")
    carpeta.mkdir(parents=True, exist_ok=True)

    resum = []
    for i, g in enumerate(triats, 1):
        print(f"\n{'=' * 78}\n[{i}/{len(triats)}] {g['group_id']} · {g['tipus']} · {g['n_alertes']} alertes · "
              f"{' → '.join(g['regles'][:6])}\n  compartit: {', '.join(g['entitats_compartides'][:3])}\n{'=' * 78}")
        sortida = carpeta / f"{g['group_id']}.json"
        os.environ["SOC_OUTPUT_PATH"] = str(sortida)               # l'agent v2 hi desa el tiquet
        t0 = time.perf_counter()
        try:
            with runbook_temporal(g), contextlib.redirect_stdout(SoloTraza(sys.stdout)):
                ag.agente_main(alerta_de_grupo(g, per_id))
            t = json.loads(sortida.read_text(encoding="utf-8"))
            t["alert_ids"] = sorted(set(t["alert_ids"]) | set(g["alert_ids"]))   # el tiquet cobreix tot el grup
            t["group_id"] = g["group_id"]
            sortida.write_text(json.dumps(t, indent=2, ensure_ascii=False), encoding="utf-8")
            seg = time.perf_counter() - t0
            print(f"\n   ➜ VEREDICTE: {t['verdict']} | SEVERITAT: {t['severity']} (regla màx: {g['severitat_regla_max']}) "
                  f"| CONFIANÇA: {t['confidence']} | {seg:.0f}s\n   Títol: {t['title']}\n   Resum: {t['summary'][:500]}")
            resum.append((g["group_id"], g["n_alertes"], t["verdict"], t["severity"], t["confidence"], f"{seg:.0f}s", ""))
        except SystemExit as e:
            print(f"\n   ✖ Aturat: {e}"); break
        except Exception as e:
            print(f"\n   ✖ ERROR: {type(e).__name__}: {str(e)[:300]}")
            resum.append((g["group_id"], g["n_alertes"], "ERROR", "-", "-", f"{time.perf_counter() - t0:.0f}s", type(e).__name__))
    os.environ.pop("SOC_OUTPUT_PATH", None)

    print(f"\n\n{'=' * 78}\nRESUM\n{'=' * 78}")
    print(f"{'grup':<10}{'alert.':<8}{'veredicte':<22}{'sever.':<14}{'conf.':<7}{'temps':<7}")
    for r in resum:
        print(f"{r[0]:<10}{r[1]:<8}{r[2]:<22}{r[3]:<14}{str(r[4]):<7}{r[5]:<7}{r[6]}")
    print(f"\nTiquets a {carpeta}")


if __name__ == "__main__":
    main()
